<?php

use Illuminate\Support\Facades\Route;

// thư mục là app nhưng sử dụng phải là App
use App\Http\Controllers\HomeController; 
use App\Http\Controllers\ProductsController; 
use App\Http\Controllers\AboutController;
use App\Http\Controllers\BillController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\DetailController;
use App\Http\Controllers\HomeAdController;
use App\Http\Controllers\ProductsAdController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ShippingController;
use App\Http\Controllers\UpdateProController;
use App\Http\Controllers\UserADController;



/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route::get('/', function () {
//     return view('home');
// });

// KHÁCH HÀNG

Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/sanpham', [ProductsController::class, 'list'])->name('sanpham');
Route::get('/sanpham/{product_id}', [ProductsController::class, 'detail'])->name('sanphamchitiet');
Route::get('/timkiem', [ProductsController::class, 'search'])->name('timkiem');
// Route::get('/chitiet/{id}', [ProductsController::class, 'detail'])->name('chitiet');
Route::get('/danhmuc/{category_id}', [ProductsController::class, 'getproductsByCategory'])->name('danhmuc');
Route::get('/gioithieu', [AboutController::class, 'about'])->name('gioithieu');
Route::get('/lienhe', [ContactController::class, 'contact'])->name('lienhe');
Route::get('/thanhtoan', [BillController::class, 'bill'])->name('thanhtoan');
Route::get('/giohang', [CartController::class, 'cart'])->name('giohang');
// Route::get('/chitiet', [DetailController::class, 'detail'])->name('chitiet');
Route::get('/thongtin', [ProfileController::class, 'profile'])->name('thongtin');
Route::get('/theodoidonhang', [ShippingController::class, 'shipping'])->name('theodoidonhang');

// QUẢN TRỊ

Route::get('/quantri', [ProductsAdController::class, 'homeAD'])->name('homeAD');
Route::get('/quantri/sanpham', [ProductsAdController::class, 'ProAD'])->name('sanphamAD');

Route::post('/quantri/themsanpham', [ProductsAdController::class, 'AddPro'])->name('themsanpham');

Route::get('/quantri/xoasanpham/{id}', [ProductsAdController::class, 'DeletePro'])->name('xoasanpham');

Route::get('/quantri/bangcapnhat/{id}', [ProductsAdController::class, 'UpdateForm'])->name('bangcapnhat');
Route::post('/quantri/capnhatsanpham/{id}', [ProductsAdController::class, 'UpdatePro'])->name('capnhatsanpham');

// Route::get('/quantri/capnhat', [UpdateProController::class, 'UpdatePro'])->name('capnhat');
Route::get('/quantri/nguoidung', [UserADController::class, 'UserAD'])->name('nguoidungAD');