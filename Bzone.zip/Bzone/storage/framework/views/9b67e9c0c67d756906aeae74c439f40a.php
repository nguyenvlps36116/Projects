
<?php $__env->startSection('title','Sản Phẩm'); ?>
<?php $__env->startSection('titlePage','Danh Sách Sản Phẩm'); ?>
<?php $__env->startSection('main'); ?>
<div class="container">
    <div class="left-box">
        <h2>Danh Mục</h2>
        <!-- Danh sách danh mục -->
        <ul>
            <li>
                <a style="font-weight: initial" href="<?php echo e(asset('sanpham')); ?>">Tất cả sản phẩm</a>
            </li>
            <?php $__currentLoopData = $Category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="<?php echo e(route('danhmuc',$item->id)); ?>"><?php echo e($item -> name); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            
            <!-- Thêm danh mục cần hiển thị -->
        </ul>
    </div>

    <div class="right-box">
        <div class="search">
            <form action="<?php echo e(route('timkiem')); ?>" method="GET">
                <input type="text" name="query" placeholder="Tìm kiếm sản phẩm" value="<?php echo e(request()->input('query')); ?>">
                <button type="submit">Tìm Kiếm</button>
            </form>
        </div>
        
        <div class="product-list">
            <!-- Danh sách sản phẩm -->
            <?php $__currentLoopData = $All; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="product">
            <a class="pro" href="<?php echo e(route('sanphamchitiet',$item->id)); ?> ">
                <img src="<?php echo e(asset('uploaded/'.$item->img)); ?>" alt="" />
            <h3><?php echo e($item -> name); ?></h3>
            </a>
            <p><?php echo e(number_format($item->price, 0, ',', '.')); ?> VNĐ</p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <div class="pagination1">
            <!-- Phân trang -->
            
            
            <?php echo e($All->links('vendor.pagination.bootstrap-4')); ?>


            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Bzone\resources\views/products/list.blade.php ENDPATH**/ ?>