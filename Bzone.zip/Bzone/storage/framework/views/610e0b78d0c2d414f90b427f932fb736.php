<nav>
    <ul>
        <li><a href="<?php echo e(asset('quantri')); ?>">Trang Chủ</a></li>
        <li><a href="<?php echo e(asset('quantri/sanpham')); ?>">Sản phẩm</a></li>
        <li><a href="<?php echo e(asset('quantri/nguoidung')); ?>">Người dùng</a></li>
        <li><a href="/">Cửa Hàng</a></li>
        
    </ul>
</nav><?php /**PATH C:\laragon\www\Bzone\resources\views/admin/HeaderAD.blade.php ENDPATH**/ ?>