
<?php $__env->startSection('title','Giới Thiệu'); ?>
<?php $__env->startSection('titlePage','Giới Thiệu'); ?>
<?php $__env->startSection('main'); ?>
<div class="container_cart">
    <div class="about-box">
        <p>Chào mừng bạn đến với trang giới thiệu. Chúng tôi là một website đơn giản với các sản phẩm mới nhất.</p>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Bzone\resources\views/about.blade.php ENDPATH**/ ?>