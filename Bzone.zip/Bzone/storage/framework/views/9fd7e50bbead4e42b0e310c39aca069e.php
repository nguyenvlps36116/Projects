<nav>
    <a href="/">Trang Chủ</a>
    <a href="<?php echo e(asset('sanpham')); ?>">Sản phẩm</a>
    <a href="<?php echo e(asset('gioithieu')); ?>">Giới Thiệu</a>
    <a href="<?php echo e(asset('lienhe')); ?>">Liên Hệ</a>
    <a href="<?php echo e(route('homeAD')); ?>">admin</a>
</nav><?php /**PATH C:\laragon\www\Bzone\resources\views/header.blade.php ENDPATH**/ ?>