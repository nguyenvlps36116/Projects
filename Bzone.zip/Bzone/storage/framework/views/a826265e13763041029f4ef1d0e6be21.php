
<?php $__env->startSection('title','Admin'); ?>
<?php $__env->startSection('titlePage','Admin'); ?>
<?php $__env->startSection('main'); ?>

<section>
    <div class="container">
        <div class="col3">
            <h2>Cập Nhật Sản Phẩm</h2>
            <form action="<?php echo e(route('capnhatsanpham', ['id' => $product->id])); ?>" method="POST" enctype="multipart/form-data">
                <label for="">Danh mục:</label>
                <?php echo csrf_field(); ?>
                <select name="category_id" id="" class="styled-select">
                    <option value="0" selected>Chọn danh mục</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->id===$product->category_id): ?>
                            <option value="<?php echo e($item->id); ?>" selected><?php echo e($item->name); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select><br>
                <label for="">Tên:</label>
                <input type="text" name="name"  value="<?php echo e($product->name); ?>" placeholder="Tên sản phẩm">

                <label for="">Giá:</label>
                <input type="text" name="price" value="<?php echo e($product->price); ?>" placeholder="Giá">

                <label for="">Số lượng:</label>
                <input type="text" name="quantity" value="<?php echo e($product->quantity); ?>" placeholder="Số lượng">

                <label for="">Hình ảnh:</label>
                <input type="file" name="img"> <!-- Thêm trường nhập hình ảnh -->
                <img style="width: 120px" src="<?php echo e(asset('uploaded/'.$product->img)); ?>" alt="">
                <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                <input type="submit" value="Cập nhật">
            </form>
        </div>
        <div class="col9">
            <h2>Danh Sách Sản Phẩm</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th><?php echo e($product->category_id); ?>

                        <th>Hình ảnh</th>
                        <th>Tên Sản Phẩm</th>
                        <th>Giá (VNĐ)</th>
                        <th>Số lượng</th>
                        <th>Lượt xem</th>
                        <th>Lượt bán</th>
                        <th>Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->id); ?></td>
                        <td><img style="width: 150px;height: 150px;" src="<?php echo e(asset('uploaded/'.$item->img)); ?>" alt=""></td>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e(number_format($item->price, 0, ',', '.')); ?></td>
                        <td><?php echo e($item->quantity); ?></td>
                        <td><?php echo e($item->view); ?></td>
                        <td><?php echo e($item->sold); ?></td>
                        <td class="action-icons">
                            <a href="<?php echo e(route('bangcapnhat', ['id' => $item->id])); ?>"><i class="fa-solid fa-pen-to-square"></i></a>-
                            <a href="<?php echo e(route('xoasanpham', ['id' => $item->id])); ?>"><i class="fa-solid fa-trash-can"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="pagination1">
                <!-- Phân trang -->
                <?php echo e($products->links('../vendor.pagination.bootstrap-4')); ?>

            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layoutAD', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Bzone\resources\views/admin/UpdateForm.blade.php ENDPATH**/ ?>