
<?php $__env->startSection('title','Chi Tiết'); ?>
<?php $__env->startSection('titlePage','Chi Tiết Sản Phẩm'); ?>
<?php $__env->startSection('main'); ?>
<div class="container_cart">
    <div class="product-detail">
        <div class="product-image">
            <img src="<?php echo e(asset('img/'.$sp->img)); ?>" alt="Product 1">
        </div>
        <div class="product-info">
            <h2><?php echo e($sp->name); ?></h2>
            <p>Mô tả chi tiết về sản phẩm. Sản phẩm này có những đặc điểm nổi bật và phù hợp cho...</p>
            <p>Giá: <?php echo e(number_format($sp->price, 0, ',', '.')); ?> VNĐ</p>
            <a style="text-decoration: none" href="#" class="order-button">Đặt Hàng</a>
        </div>
    </div>
    <h3 style="text-align: center; font-weight: bold; color: #316b7d">Sản Phẩm Liên Quan</h3>

    <div class="related-products1">
        <?php $__currentLoopData = $splq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="product1">
            <a href="<?php echo e(route('sanphamchitiet',$sp->id)); ?>">
                <div class="product-image1">
                    <img src="<?php echo e(asset('img/'.$sp->img)); ?>" alt="Product 2">
                </div>
            </a>
            <div class="product-info1">
                <a href="<?php echo e(route('sanphamchitiet',$sp->id)); ?>">
                    <h4><?php echo e($sp->name); ?></h4>
                </a>
                <p>Giá: <?php echo e(number_format($sp->price, 0, ',', '.')); ?> VNĐ</p>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Bzone\resources\views/products/detail.blade.php ENDPATH**/ ?>