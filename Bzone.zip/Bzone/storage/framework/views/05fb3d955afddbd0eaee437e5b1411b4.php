
<?php $__env->startSection('title','Basketball Zone'); ?>
<?php $__env->startSection('titlePage','Trang Chủ'); ?>
<?php $__env->startSection('main'); ?>
<div class="container">
    <h2>Sản Phẩm Mới</h2>
    <div class="product-box">
        <?php $__currentLoopData = $New; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="product">
            <a class="pro" href="chitiet">
                <img src="<?php echo e(asset('uploaded/'.$product->img)); ?>" alt="" />
            <h3><?php echo e($product -> name); ?></h3>
            </a>
            <p><?php echo e(number_format($product->price, 0, ',', '.')); ?> VNĐ</p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </div>
    <h2>Sản Phẩm Bán Chạy</h2>
    <div class="product-box">
        <?php $__currentLoopData = $BestSeller; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="product">
            <a class="pro" href="chitiet">
                <img src="<?php echo e(asset('uploaded/'.$product->img)); ?>" alt="" />
            <h3><?php echo e($product -> name); ?></h3>
            </a>
            <p><?php echo e(number_format($product->price, 0, ',', '.')); ?> VNĐ</p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <h2>Sản Phẩm Xem Nhiều</h2>
    <div class="product-box">
        <?php $__currentLoopData = $Views; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="product">
            <a class="pro" href="chitiet">
                <img src="<?php echo e(asset('uploaded/'.$product->img)); ?>" alt="" />
            <h3><?php echo e($product -> name); ?></h3>
            </a>
            <p><?php echo e(number_format($product->price, 0, ',', '.')); ?> VNĐ</p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Bzone\resources\views/home.blade.php ENDPATH**/ ?>