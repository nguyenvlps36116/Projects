<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('Admin/css/style1.css')); ?>" />
    <script src="https://kit.fontawesome.com/4b1791cf7d.js" crossorigin="anonymous"></script>

</head>

<body>
    <header>
        <h1><?php echo $__env->yieldContent('titlePage'); ?></h1>
    </header>
    <?php echo $__env->make('admin.HeaderAD', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main>
        <?php echo $__env->yieldContent('main'); ?>
    </main>
    <!-- <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->

</body><?php /**PATH C:\laragon\www\Bzone\resources\views/admin/layoutAD.blade.php ENDPATH**/ ?>