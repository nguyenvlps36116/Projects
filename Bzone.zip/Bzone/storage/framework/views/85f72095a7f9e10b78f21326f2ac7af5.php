
<?php $__env->startSection('title','Chi Tiết'); ?>
<?php $__env->startSection('titlePage','Chi Tiết'); ?>
<?php $__env->startSection('main'); ?>
<body>
    <div class="container_cart">
        <div class="product-detail">
            <div class="product-image">
                <img src="img/hinh1.webp" alt="Product 1">
            </div>
            <div class="product-info">
                <h2>Tên Sản Phẩm</h2>
                <p>Mô tả chi tiết về sản phẩm. Sản phẩm này có những đặc điểm nổi bật và phù hợp cho...</p>
                <p>Giá: $99.99</p>
                <button class="order-button">Đặt Hàng</button>
            </div>
        </div>

        <h3 style="text-align: center">Sản Phẩm Liên Quan</h3>
        <div class="related-products">
            <div class="product1">
                <a href="">
                    <div class="product-image">
                        <img src="img/hinh2.webp" alt="Product 2">
                    </div>
                </a>
                <div class="product-info">
                    <h4>Tên Sản Phẩm 2</h4>
                    <p>Giá: $79.99</p>
                </div>
                
            </div>
            <div class="product1">
                <a href="">
                    <div class="product-image">
                        <img src="img/hinh3.webp" alt="Product 3">
                    </div>
                </a>
                <div class="product-info">
                    <h4>Tên Sản Phẩm 3</h4>
                    <p>Giá: $89.99</p>
                </div>
            </div>
            <div class="product1">
                <a href="">
                    <div class="product-image">
                        <img src="img/hinh4.webp" alt="Product 4">
                    </div>
                </a>
                <div class="product-info">
                    <h4>Tên Sản Phẩm 4</h4>
                    <p>Giá: $99.99</p>
                </div>
            </div>
            
        </div>
    </div>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Bzone\resources\views/detail.blade.php ENDPATH**/ ?>