
<?php $__env->startSection('title','Admin'); ?>
<?php $__env->startSection('titlePage','Admin'); ?>
<?php $__env->startSection('main'); ?>

<section>
    <div class="container2">
        <section>
            <form action="<?php echo e(route('themsanpham')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <select name="category_id" id="" class="styled-select">
                    <option value="0" selected>Chọn danh mục</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <label for="product_name">Tên sản phẩm:</label><br>
                <input type="text" id="product_name" name="name"><br>

                <label for="product_price">Giá:</label><br>
                <input type="text" id="product_price" name="price"><br>

                <label for="product_image">Hình ảnh:</label><br>
                <input type="file" id="product_image" name="img"><br>

                <input type="submit" value="Cập nhật">
            </form>
                
        </section>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layoutAD', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Bzone\resources\views/admin/UpdateProduct.blade.php ENDPATH**/ ?>