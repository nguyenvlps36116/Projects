<nav>
    <a href="/">Trang Chủ</a>
    <a href="/sanpham">Sản phẩm</a>
    <a href="/gioithieu">Giới Thiệu</a>
    <a href="/lienhe">Liên Hệ</a>
</nav><?php /**PATH C:\laragon\www\Bzone\resources\views/headerAD.blade.php ENDPATH**/ ?>