<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BillController extends Controller
{
    //
    public function bill(){
        // about là lấy tên sau ::class
        return view('bill');
    }
}