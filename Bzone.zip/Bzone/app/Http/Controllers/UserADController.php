<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserADController extends Controller
{
    public function UserAD(){
        // products là thư mục chưa list
        return view('admin.UsersAD');
    }
}