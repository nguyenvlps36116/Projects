<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CartController extends Controller
{
    //
    public function cart(){
        // about là lấy tên sau ::class
        return view('cart');
    }
}