<nav>
    <ul>
        <li><a href="{{asset('quantri')}}">Trang Chủ</a></li>
        <li><a href="{{asset('quantri/sanpham')}}">Sản phẩm</a></li>
        <li><a href="{{asset('quantri/nguoidung')}}">Người dùng</a></li>
        <li><a href="/">Cửa Hàng</a></li>
        {{-- <li><a href="/quantri/capnhat">Form Cập nhật</a></li> --}}
    </ul>
</nav>