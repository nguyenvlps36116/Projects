<nav>
    <a href="/">Trang Chủ</a>
    <a href="{{asset('sanpham')}}">Sản phẩm</a>
    <a href="{{asset('gioithieu')}}">Giới Thiệu</a>
    <a href="{{asset('lienhe')}}">Liên Hệ</a>
    <a href="{{ route('homeAD') }}">admin</a>
</nav>