@extends('layout')
@section('title','Giỏ Hàng')
@section('titlePage','Giỏ Hàng')
@section('main')

<body class="body5">
    <div class="container_cart5">
        <div class="cart-item5" data-product-id="1">
            <div class="product-image5">
                <img src="img/hinh1.webp" alt="Product 1">
            </div>
            <div class="product-info5">
                <h4>Tên Sản Phẩm 1</h4>
                <p>Giá: $99.99</p>
            </div>
            <div class="quantity5">
                <button class="decrease-btn5">-</button>
                <span class="quantity-value5">1</span>
                <button class="increase-btn5">+</button>
            </div>
            <div class="product-actions5">
                <button class="remove-btn5">Xóa</button>
            </div>
        </div>

        <div class="cart-item5" data-product-id="2">
            <div class="product-image5">
                <img src="img/hinh2.webp" alt="Product 2">
            </div>
            <div class="product-info5">
                <h4>Tên Sản Phẩm 2</h4>
                <p>Giá: $79.99</p>
            </div>
            <div class="quantity5">
                <button class="decrease-btn5">-</button>
                <span class="quantity-value5">2</span>
                <button class="increase-btn5">+</button>
            </div>
            <div class="product-actions5">
                <button class="remove-btn5">Xóa</button>
            </div>
        </div>

        <!-- Add more cart items as needed -->

        <button class="continue-btn5">Tiếp Tục Đặt Hàng</button>
    </div>
</body>
@endsection